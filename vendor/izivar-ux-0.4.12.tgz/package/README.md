# @izivar/ux

Shared UI library for all IZIVAR web apps — design tokens, primitives, icons, and platform chrome built on React 19, Tailwind v4, and Radix UI.

---

## Contents

- [What's in this package](#whats-in-this-package)
- [Installing in a consuming app](#installing-in-a-consuming-app)
- [Using the design system](#using-the-design-system)
- [Storybook](#storybook)
- [Adding a new component](#adding-a-new-component)
- [Adding a new icon](#adding-a-new-icon)
- [Icon rules](#icon-rules)
- [Versioning](#versioning)
- [Build](#build)
- [Publish to GCP Artifact Registry](#publish-to-gcp-artifact-registry)
- [CI / GitHub Actions](#ci--github-actions)
- [Local development (monorepo)](#local-development-monorepo)

---

## What's in this package

| Category | Contents |
|---|---|
| **UI primitives** (`src/components/ui/`) | 30+ shadcn-style components: Button, Input, Dialog, Drawer, Checkbox, Calendar, Combobox, Select, Textarea, Card, Popover, DropdownMenu, NavigationMenu, RadioGroup, Switch, Label, Alert, Avatar, Badge, Breadcrumb, Tabs, Tooltip, Toggle, ToggleGroup, Slider, Progress, Stepper, Sonner, SplitButton, List, FieldGroup, EmptyState, FormCard, FormActions |
| **Data-display** (`src/components/data-display/`) | DataTable, StatCard, StatusBadge, PageHeader, ConfirmDialog, RejectDialog, SuspendDialog, QueryListBoundary |
| **Icons** (`src/shared/icons/`) | 76 SVG icon components — all `currentColor`, `strokeWidth="2"`, `aria-hidden` |
| **Platform chrome** (`src/platform/`) | Header, Footer, LandingHeader (props-driven, no hardcoded content) |
| **Design system** (`src/design-system/`) | `cssVar` map (CSS variables), `typography` map (12 fluid classes), typed token helpers |
| **Hooks** (`src/hooks/`) | `useDebounce`, `useMediaQuery`, `useClickOutside` |
| **Utilities** (`src/utils/`) | `cn` (clsx + tailwind-merge) |
| **Styles** (`src/styles/izivar-globals.css`) | CSS variables (light + dark), Tailwind v4 `@theme`, fluid typography scale, responsive utilities |

---

## Installing in a consuming app

### Monorepo (local dev)

The monorepo `pnpm-workspace.yaml` resolves `@izivar/ux` via `workspace:*`. No extra steps.

```jsonc
// apps/your-app/package.json
{
  "dependencies": {
    "@izivar/ux": "workspace:*"
  }
}
```

### Standalone repo (production / Vercel)

`@izivar/ux` is published to GCP Artifact Registry. Add an `.npmrc` in the consuming repo:

```ini
# .npmrc
@izivar:registry=https://REGION-npm.pkg.dev/PROJECT_ID/REPO_NAME/
//REGION-npm.pkg.dev/PROJECT_ID/REPO_NAME/:_authToken=${GAR_TOKEN}
```

Then reference a pinned version:

```jsonc
{
  "dependencies": {
    "@izivar/ux": "^0.3.1"
  }
}
```

### Import styles once (app root)

```css
/* app/globals.css — import before any other styles */
@import "@izivar/ux/globals.css";
```

---

## Using the design system

### CSS variables (Tailwind semantic utilities — preferred)

Always prefer Tailwind semantic class names over arbitrary values:

```tsx
// ✅ correct
<div className="bg-card text-foreground border-border" />

// ❌ wrong — breaks dark mode and theming
<div style={{ background: "#fff", color: "#0F172A" }} />
```

### CSS variables (runtime / style props)

Use `cssVar` when you need the variable name as a string (canvas, charts, animations):

```tsx
import { cssVar } from "@izivar/ux";

<div style={{ color: `var(${cssVar.primary})` }} />
```

### Typography

Use the typed `typography` map or the class names directly:

```tsx
import { typography } from "@izivar/ux/design-system";
import { cn } from "@izivar/ux";

// via constant
<h1 className={cn(typography.headlineLarge)}>Title</h1>

// or directly
<h2 className="headline-medium">Section</h2>
<p className="paragraph-medium">Body copy</p>
```

| Class | Size | Weight | Use for |
|---|---|---|---|
| `headline-large` | 24→36px fluid | 700 | Page titles |
| `headline-medium` | 20→30px fluid | 700 | Section titles |
| `headline-small` | 18→24px fluid | 700 | Card/modal headings |
| `title-large` | 18→24px fluid | 600 | Sub-section headings |
| `title-medium` | 16→20px fluid | 600 | Sidebar / nav headings |
| `title-small` | 14→16px fluid | 600 | Labels, compact headings |
| `paragraph-large` | 16px fixed | 400 | Primary body text |
| `paragraph-medium` | 14px fixed | 400 | Secondary body text |
| `paragraph-small` | 12px fixed | 400 | Captions, meta |
| `label-large` | 16px fixed | 600 | Button text, form labels |
| `label-medium` | 14px fixed | 600 | Navigation, tags |
| `label-small` | 12px fixed | 600 | Badges, captions (muted) |
| `label-xs` | 10px fixed | 700 | Eyebrows, micro-labels |

---

## Storybook

Storybook is the live documentation and visual reference for every component, icon, and design token in this library.

### Run locally

```bash
# From this package directory
pnpm storybook

# Opens at http://localhost:6006
```

### What's documented

| Storybook section | What it shows |
|---|---|
| **Foundation / Colors** | All CSS token swatches grouped by category (Brand, Surface, Semantic, Border, Sidebar). Text color tokens with live samples. Semantic usage guide (when to reach for each token). |
| **Foundation / Typography** | Full type scale — every class with size, weight, and live sample text. "In Context" card showing hierarchy. Color token combinations. |
| **Icons / Gallery** | All 76 icons in a responsive grid with `size` and `color` controls. Size comparison and color token demos. |
| **UI / \*** | Every primitive component with variants, states, and real izivar data examples. |
| **Data Display / \*** | DataTable (default, loading, empty), StatCard, PageHeader, StatusBadge, dialogs. |

### Addons

| Addon | Purpose |
|---|---|
| `@storybook/addon-essentials` | Controls, actions, docs, viewport, backgrounds |
| `@storybook/addon-a11y` | Accessibility audit — flags contrast violations, missing ARIA labels, keyboard issues per story |

### A11y checks

Every story is automatically scanned by the **Accessibility** panel (bottom of Storybook). Before shipping a component:

1. Open the story in Storybook
2. Click the **Accessibility** tab in the bottom panel
3. Resolve any **violations** (red) — warnings (yellow) should be reviewed
4. Common issues: insufficient color contrast, missing `aria-label` on icon-only buttons, unlabelled form inputs

### Adding a story

Create a `ComponentName.stories.tsx` file next to the component file:

```tsx
import type { Meta, StoryObj } from "@storybook/react";
import { MyComponent } from "./my-component";

const meta: Meta<typeof MyComponent> = {
  title: "UI/MyComponent",
  component: MyComponent,
  tags: ["autodocs"],
};
export default meta;
type Story = StoryObj<typeof MyComponent>;

export const Default: Story = {
  args: { label: "Example" },
};
```

**Rules for stories:**
- Use real izivar data — hotel names, Indian locations, actual status values (`ACTIVE`, `PENDING_REVIEW`, etc.)
- Cover the meaningful states: default, disabled, error, loading, empty
- Never use `args` for dynamic class names — Tailwind JIT cannot scan runtime-constructed strings. Use `style={{ color: "var(--token)" }}` for token-driven inline styles

---

## Adding a new component

Follow this checklist exactly.

### 1. Choose the right location

| Type | Location |
|---|---|
| Low-level primitive (wraps a Radix or HTML element) | `src/components/ui/` |
| Composed / data-display (uses multiple primitives) | `src/components/data-display/` |
| App chrome (layout-level, full-width) | `src/platform/` |
| Cross-cutting utility (banners, skeletons, icons) | `src/shared/components/ui/` |

### 2. Create the component file

```tsx
// src/components/ui/badge.tsx
"use client"; // only if the component uses hooks or browser APIs

import { cn } from "../../utils/cn";

interface BadgeProps {
  children: React.ReactNode;
  variant?: "default" | "success" | "warning" | "destructive";
  className?: string;
}

export function Badge({ children, variant = "default", className }: BadgeProps) {
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 rounded-full label-small", className)}>
      {children}
    </span>
  );
}
```

**Rules:**
- Never hardcode hex/rgba — use CSS variable tokens or Tailwind semantic utilities only
- Never import shadcn primitives directly in apps — wrap here and re-export from `@izivar/ux`
- All props must be typed — no `any`
- Use `cn()` for conditional classes — never string concatenation

### 3. Export from the barrel

```ts
// src/components/ui/index.ts
export * from "./badge";
```

### 4. Add a Storybook story

```tsx
// src/components/ui/badge.stories.tsx
```

### 5. Build and verify

```bash
pnpm run build
pnpm run typecheck
```

### 6. Update CHANGELOG

Under `## [Unreleased]` → `### Added`:
```markdown
- **`Badge`** — status badge with `default`, `success`, `warning`, `destructive` variants.
```

---

## Adding a new icon

All icons live in `src/shared/icons/` as individual React components.

### 1. Create the icon file

```tsx
// src/shared/icons/StarFilledIcon.tsx

interface StarFilledIconProps {
  className?: string;
  size?: number;
  style?: React.CSSProperties;
}

export function StarFilledIcon({ className = '', size = 24, style }: StarFilledIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={style}
      aria-hidden="true"
    >
      <path
        d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
        fill="currentColor"
      />
    </svg>
  );
}
```

### 2. Export from the icon barrel

```ts
// src/shared/icons/index.ts — add alphabetically
export { StarFilledIcon } from "./StarFilledIcon";
```

### 3. Update CHANGELOG

```markdown
- **`StarFilledIcon`** — filled star for ratings and favourites.
```

---

## Icon rules

All icons in this library must follow these rules — no exceptions:

| Rule | Why |
|---|---|
| Use `currentColor` for all `stroke` and `fill` | Inherits `text-*` class from parent — one icon works in any color context |
| `strokeWidth="2"` on all stroke icons | Consistent visual weight at 24×24px |
| `viewBox="0 0 24 24"` | Standard grid — do not change |
| `aria-hidden="true"` | Icons are decorative — label the parent button/link instead |
| No hardcoded hex (`#FF6F61`, `#22C55E`, etc.) | Breaks theming, dark mode, and color controls in Storybook |
| No hardcoded CSS vars (`var(--primary)`) | Use `currentColor` — the parent controls color via `text-*` |
| Props: `size`, `className`, `style` | Consistent API across all 76 icons |

---

## Versioning

This package follows [Semantic Versioning](https://semver.org/).

| Change type | Bump | Example |
|---|---|---|
| Breaking — removed export, renamed prop, changed token | **MAJOR** | Rename `Button` prop `variant="ghost"` → `variant="text"` |
| New component, icon, token (backwards compatible) | **MINOR** | Add `Badge` |
| Bug fix, style tweak, docs | **PATCH** | Fix button hover colour |

### Release checklist

1. Update `CHANGELOG.md` — move `[Unreleased]` to a dated section
2. Bump `package.json` version: `pnpm version minor`
3. Commit: `git commit -m "chore: release v0.3.0"`
4. Tag and push: `git tag v0.3.0 && git push origin main --tags`

The `v*` tag triggers CI `publish` automatically.

---

## Build

```bash
pnpm run build

# From monorepo root
pnpm --filter @izivar/ux run build
```

Output (`dist/`) is unbundled ESM — each `src/` file becomes a separate `.js` + `.d.ts`. This lets Next.js Server Components tree-shake individual modules.

---

## Publish to GCP Artifact Registry

Publishing is handled by GitHub Actions on a `v*` tag push.

### One-time setup

1. Create an npm repository in GCP Artifact Registry (format: `npm`)
2. Create a service account with `roles/artifactregistry.writer`
3. Set up Workload Identity Federation between GitHub and GCP
4. Add GitHub secrets: `GCP_WORKLOAD_IDENTITY_PROVIDER`, `GCP_SERVICE_ACCOUNT`, `GAR_LOCATION`, `GCP_PROJECT_ID`, `GAR_NPM_REPO`
5. Update `publishConfig` in `package.json` with the real registry URL

### Manual publish (emergency only)

```bash
gcloud auth login
echo "@izivar:registry=https://REGION-npm.pkg.dev/PROJECT_ID/REPO_NAME/" >> ~/.npmrc
echo "//REGION-npm.pkg.dev/PROJECT_ID/REPO_NAME/:_authToken=$(gcloud auth print-access-token)" >> ~/.npmrc
pnpm run build && npm publish --ignore-scripts
```

---

## CI / GitHub Actions

Single workflow: **[`CI / Publish`](.github/workflows/ci.yml)**

| Trigger | `validate` job | `publish` job |
|---|---|---|
| Pull request | Yes | No |
| Push to `main` or `release/development` | Yes | No |
| Push tag `v*` | Yes + version check | Yes |
| `workflow_dispatch` | Yes | Yes |

**`validate` job:** lint → typecheck → audit → test → build → SBOM. On `v*` tag: verifies `package.json` version matches the tag.

**`publish` job:** downloads `dist/` artifact from `validate`, authenticates to GCP via Workload Identity Federation (keyless), publishes to Artifact Registry.

### Lockfile — current state and migration target

CI currently installs with `--no-frozen-lockfile`, which means pnpm resolves the latest
compatible versions at install time. This makes dependency versions non-deterministic
between runs — a security and reproducibility risk.

```yaml
# Current (insecure — deps can drift between runs)
run: pnpm install --no-frozen-lockfile

# Target (reproducible — same dep tree every run)
run: pnpm install --frozen-lockfile
```

**To migrate:**

1. Commit `pnpm-lock.yaml` to the repository (it is currently git-ignored or absent).
2. Change both `pnpm install` lines in `.github/workflows/ci.yml` from `--no-frozen-lockfile` to `--frozen-lockfile`.
3. From that point on, update the lockfile locally (`pnpm install`) and commit the updated `pnpm-lock.yaml` whenever dependencies change.

Until the lockfile is committed, `--no-frozen-lockfile` is intentional — **do not switch the CI flag without committing the lockfile first** or every CI run will fail immediately.

---

## Local development (monorepo)

```bash
# Run Storybook
pnpm storybook

# Run quality checks
pnpm run lint
pnpm run typecheck
pnpm run test
pnpm run build

# From monorepo root
pnpm --filter @izivar/ux run <script>
```

### Pre-commit hook

Husky runs on `git commit`:
- **lint-staged**: ESLint on staged `*.{ts,tsx}` (`--max-warnings=0`)
- **Vitest**: full test suite

```bash
pnpm install  # installs hooks via `prepare: husky`
```
