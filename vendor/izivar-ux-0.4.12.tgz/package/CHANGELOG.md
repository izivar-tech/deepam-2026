# Changelog

All notable changes to **`@izivar/ux`** (`izivar-ux-lib`) are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.4.12] - 2026-10-28

### Added

- **`BalconyAmenityIcon`** — balcony/terrace amenity icon.
- **`BathrobeAmenityIcon`** — bathrobe amenity icon (stroke-based, no solid fill).
- **`ElectricKettleAmenityIcon`** — electric kettle amenity icon.
- **`EvChargerAmenityIcon`** — EV charger amenity icon with lightning bolt accent.
- **`HairDryerAmenityIcon`** — hair dryer amenity icon with heat wave accent.

### Changed

- **`FireplaceAmenityIcon`** — converted from solid fill to stroke-based to match icon set visual weight.
- **`ReceptionAmenityIcon`** — restyled as outline-based bell + counter design.
- **`SecurityAmenityIcon`** — reduced stroke weight and removed filled background for consistency.
- **`WashingMachineAmenityIcon`** — adjusted viewBox to reduce visual weight.

### Fixed

- Patched audit vulnerabilities (`undici`, `zod`).

---

## [Unreleased]

---

## [0.4.11] - 2026-10-23

### Removed

- **`SharedRoomsStayIcon`** — removed shared rooms stay-type icon and `shared_rooms` entry from `STAY_TYPE_ICON_MAP` (property type no longer supported).

---

## [0.4.10] - 2026-10-04

### Added

- **`DownloadIcon`** — file download action icon (stroke-based, lucide style). Props: `className`, `size`, `style`.
- **`ShareIcon`** — share/forward action icon (three-node graph, stroke-based). Props: `className`, `size`, `style`.

---

## [0.4.6] - 2026-08-24

### Changed

- **LandingHeader** — extended with `actions`, `accountHref`, and `labels` props to support booking-app auth buttons (`signInButton`, `accountLink`)
- **LandingHeader** — actions now hidden in mobile top bar when the mobile menu is open (consistent with secondary CTA behaviour)
- **LandingHeader** — actions rendered inside the mobile menu panel so they are reachable when the sheet is open
- **LandingHeader** — `hasMobileMenu` now includes `actions` so a header with only auth actions still shows the hamburger
- **LandingHeader** — renamed action type `"userMenu"` → `"accountLink"` to accurately reflect the link-only behaviour (**breaking** for any callers passing `"userMenu"`)
- **LandingHeader** — duplicate entries in `actions` array are silently deduplicated (no duplicate keys or double renders)
- **LandingHeader** — removed redundant `<span class="sr-only">` inside `signInButton`; `aria-label` on the link is sufficient

### Exports

- Added `LandingHeaderAction` and `LandingHeaderLabels` type exports from `@izivar/ux/platform`

---

## [0.4.3] - 2026-08-11

### Changed

- **ReceptionAmenityIcon** — removed `#FFB38F` bell dome fill; body is now transparent (outline only)
- **PetFriendlyAmenityIcon** — main paw pad changed from `#FF6F61` to `#FFB38F`; all pads now uniform light orange with `#1E3350` outline
- **NearTempleHighlightIcon** — switched from solid `#1E3350` fill to `fill="none"` + `stroke="#1E3350"` line-art style
- **HillViewHighlightIcon** — same line-art treatment as NearTemple
- **SmokeAreaAmenityIcon** — reduced `strokeWidth` from `1.5` → `1` for lighter line weight

---

## [0.4.2] - 2026-08-11

### Changed

- **Amenity icons** — reworked high-contrast icons (`ReceptionAmenityIcon`, `PetFriendlyAmenityIcon`, `FireplaceAmenityIcon`, `HotTubAmenityIcon`) to reduce dark-fill dominance; redistributed brand colors so `#FFB38F` fills main body and `#1E3350` is used for structural outlines only
- **Amenity icons** — replaced `PrivateBathroomAmenityIcon` and `IronBoxAmenityIcon` SVGs with corrected artwork; brand colors applied across all three layers
- **Amenity icons** — applied brand color palette to `HouseKeepingAmenityIcon` (was monochrome `#1E3350`): shelves in `#FF6F61`, wheels/buttons in `#FFB38F`, frame in `#1E3350`
- **Highlight icons** — applied brand color accents to `NearTempleHighlightIcon` (spire bands in `#FF6F61`, kalasha in `#FFB38F`) and `HillViewHighlightIcon` (peak in `#FF6F61`, foreground hill in `#FFB38F`); both were previously monochrome

---

## [0.4.1] - 2026-08-11

### Changed

- **Amenity icons** — applied three-color brand palette (`#1E3350`, `#FF6F61`, `#FFB38F`) to `CctvAmenityIcon`, `ChildcareAmenityIcon`, `FireplaceAmenityIcon`, `FirstAidAmenityIcon`, `HotTubAmenityIcon`, `KitchenAmenityIcon`, `ReceptionAmenityIcon`; replaced `LaundryAmenityIcon` and `MicrowaveAmenityIcon` SVGs with higher-quality artwork and brand colors
- **Stay-type icon** — replaced `ResortStayIcon` SVG with Figma-sourced artwork in native `0 0 24 24` viewBox with brand colors

---

## [0.4.0] - 2026-08-11

### Added

- **Amenity icons** — 3 new SVG components: `CctvAmenityIcon`, `IronBoxAmenityIcon`, `MicrowaveAmenityIcon`; all exported from `@izivar/ux`
- **Highlight icon** — `BeachHighlightIcon` replaces `SeaViewHighlightIcon`
- **Stay-type icon** — `SharedRoomsStayIcon` replaces `GuestHouseStayIcon`
- **General icons** — 5 new: `CameraIcon`, `CreditCardIcon`, `BookOpenIcon`, `CarIcon`, `HashIcon`; all exported from `@izivar/ux`
- **`LandingHeader`** — new optional props `brandLogoSrc?: string` and `brandLogoAlt?: string`; when `brandLogoSrc` is provided, renders an `<img>` logo instead of the text brand name (alt defaults to `brandName`)

### Changed

- **SVG icon quality** — all 26 amenity icons, highlight icons (`CityCentreHighlightIcon`, `CountrysideHighlightIcon`, `HillViewHighlightIcon`, `NearTempleHighlightIcon`), and stay-type icons redrawn with improved paths, consistent `viewBox`, and cleaner geometry
- **`PageHeader`** — `description` now renders as `<Text as="span" className="block">` instead of a block-level element, fixing inline rendering issues in certain layout contexts

### Removed

> **Breaking** — update any imports before upgrading.

- `SeaViewHighlightIcon` — use `BeachHighlightIcon` instead
- `EcoStayHighlightIcon` — removed (no direct replacement)
- `HostelStayIcon` — removed (no direct replacement)
- `GuestHouseStayIcon` — use `SharedRoomsStayIcon` instead

---

## [0.3.3] - 2026-07-14

### Added

- **`HotelStayIcon`** — new stay-type SVG icon
- **`RoomServiceAmenityIcon`** — new amenity SVG icon
- **`NumberStepper`** — numeric increment/decrement input component (`src/components/ui/number-stepper.tsx`); exported from `@izivar/ux`

---

## [0.3.2] - 2026-06-24

### Added

- **Catalog icons** — 43 SVG icon components in `src/shared/icons/catalog/` now exported from the package entry point (`@izivar/ux`):
  - **Amenities** (26): `WifiAmenityIcon`, `ParkingAmenityIcon`, `SwimmingPoolAmenityIcon`, `GymAmenityIcon`, `SpaAmenityIcon`, `RestaurantAmenityIcon`, `BreakfastAmenityIcon`, `AcAmenityIcon`, `KitchenAmenityIcon`, `LaundryAmenityIcon`, `PetFriendlyAmenityIcon`, `PrivateBathroomAmenityIcon`, `TvAmenityIcon`, `HotTubAmenityIcon`, `BarAmenityIcon`, `BeachAmenityIcon`, `FireplaceAmenityIcon`, `ConferenceAmenityIcon`, `ReceptionAmenityIcon`, `SecurityAmenityIcon`, `ChildcareAmenityIcon`, `HouseKeepingAmenityIcon`, `SmokeAreaAmenityIcon`, `FirstAidAmenityIcon`, `WashingMachineAmenityIcon`, `AirportAmenityIcon`
  - **Highlights** (10): `SeaViewHighlightIcon`, `HillViewHighlightIcon`, `NearTempleHighlightIcon`, `RiversideHighlightIcon`, `HillStationHighlightIcon`, `ForestStayHighlightIcon`, `WaterfallHighlightIcon`, `EcoStayHighlightIcon`, `CityCentreHighlightIcon`, `CountrysideHighlightIcon`
  - **Stay types** (7): `VillaStayIcon`, `ResortStayIcon`, `HomestayStayIcon`, `FarmstayStayIcon`, `GuestHouseStayIcon`, `HostelStayIcon`, `ApartmentStayIcon`
  - All icons share the standard `{ size?: number; className?: string; style?: React.CSSProperties }` props with `size` defaulting to `24`.
- **`Icons.stories.tsx`** — added `48` to the `Sizes` story and `size` control options. Gallery story auto-renders all 43 catalog icons via `import * as Icons`.

### Removed

- **`scripts/export-tokens.ts`** — deleted. Token JSON export for Figma was never wired into CI or consumed by any app. Script and `tokens:export` package.json entry removed.
- **`scripts/rewrite-imports.mjs`** — deleted. One-time migration script that rewrote `@/` alias imports to relative paths. Migration is complete; script is no longer needed.

### Fixed

- **`FormActions`** — Submit button padding corrected from `px-10` to `px-8` to match Back button width. Both buttons now stack full-width on mobile (`flex-col-reverse w-full`) and revert to inline row on `sm:` and above (`sm:flex-row sm:w-auto`). No API changes — all props unchanged.
- **`ExternalLink`** — now exported from the package entry point (`@izivar/ux`). Use instead of raw `<a target="_blank">` for all external links; blocks `javascript:` and `data:` hrefs (OWASP A03), always sets `rel="noopener noreferrer"`.

---

## [0.3.1] - 2026-06-05

### Added (i18n — Layer 1: Text prop extraction)

All hardcoded UI strings converted to props with English defaults. Zero breaking changes — existing callers require no updates. Pass translated strings from the consuming app (`next-intl`, or any i18n library) when ready.

- **`dialog.tsx` `DialogContent`** — `closeLabel?: string` (default `"Close"`). Screen-reader label on the X close button.
- **`breadcrumb.tsx` `BreadcrumbEllipsis`** — `moreLabel?: string` (default `"More"`). Screen-reader label on the ellipsis span.
- **`components/data-display/DataTable.tsx`** — `paginationLabels?: DataTablePaginationLabels` object with five overridable strings: `firstPage`, `prevPage`, `nextPage`, `lastPage` (button aria-labels), and `pageOf` (function `(page, total) => string` for the "Page X of Y" display). `DataTablePaginationLabels` is exported.
- **`platform/Header.tsx`** — `labels?: HeaderLabels` with `changeLanguage`, `signIn`, `account`, `menu`. All four action-button aria-labels and titles are now driven by this prop. `HeaderLabels` is exported.
- **`platform/LandingHeader.tsx`** — `openMenuLabel?: string` (default `"Open menu"`), `closeMenuLabel?: string` (default `"Close menu"`), `mobileNavLabel?: string` (default `"Mobile sections"`).
- **`components/ui/split-button.tsx`** — `loadingLabel?: string` (default `"Processing…"`), `moreActionsLabel?: string` (default `"More actions"`).
- **`components/ui/form-card.tsx`** — `closeLabel?: string` (default `"Close"`). aria-label for the X close button when `onClose` is provided. (`errorCardTitle` and `errorTryAgainLabel` were already props.)
- **`components/data-display/SuspendDialog.tsx`** — `labels?: SuspendDialogLabels` with `title`, `reasonLabel`, `reasonPlaceholder`, `cancelLabel`, `confirmLabel`, `loadingLabel`.
- **`components/data-display/RejectDialog.tsx`** — `labels?: RejectDialogLabels` with `title`, `description`, `reasonLabel`, `reasonPlaceholder`, `charCount` (function), `cancelLabel`, `confirmLabel`, `loadingLabel`.

**Components already i18n-ready (no change needed):** `Combobox` (placeholder, searchPlaceholder, emptyText), `DateRangePicker` (placeholder), `FormActions` (backLabel), `Footer` (linksAriaLabel, languageSwitcherLabel).

**Not converted (structural/semantic, not UI copy):** `aria-label="Primary"` on `<nav>` in `Header` and `LandingHeader`, `aria-label="breadcrumb"` on `<nav>` in `Breadcrumb` — these are ARIA landmark labels consumed by assistive technology, not visible UI text.

---

## [0.3.0] - 2026-06-05

### Fixed (Dark Mode — token visibility)

- **`izivar-globals.css` `.dark`** — added missing dark mode overrides for `--text-main`, `--text-muted`, and `--popover-border`. These tokens were light-mode only, causing headings and captions to render in near-black navy on dark backgrounds.
- **`izivar-globals.css` `:root` + `.dark`** — converted all 8 `--sidebar-*` tokens from raw HSL strings to the project oklch system. Each value maps semantically to an existing token (e.g. dark `--sidebar` = `--background` dark). Consistent with every other token in the file.
- **`--secondary-foreground`** — changed from `#fff` to `#1e3350` (navy) in light mode. Previous white gave 1.61:1 on the `#FFBE98` peach secondary surface (critical WCAG fail); navy gives **7.95:1**, passing WCAG AA.
- **`badge.tsx`** — all variants now use semantic base color tokens on tinted backgrounds instead of `-foreground` tokens. `-foreground` tokens are near-black in dark mode, invisible on `bg-color/10`–`/25` tints. Pattern applied: `text-primary` / `text-success` / `text-warning` / `text-secondary` for tinted variants; `bg-X/25` opacity in dark mode for sufficient contrast.
- **`StatusBadge.tsx`** — all 15 STATUS_MAP entries updated to use base color tokens (`text-success`, `text-warning`, `text-destructive`, `text-muted-foreground`) instead of `-foreground` suffixed tokens on tinted backgrounds. Same root cause as Badge fix above.

### Removed

- **`Stepper`** component — removed `src/components/ui/stepper.tsx`, its stories, and its unit tests. Component was unused across all consuming apps. Export removed from `src/components/ui/index.ts`.

### Added (Dark Mode — Storybook)

- **`@storybook/addon-themes`** — installed at `^8.6.18` (compatible with Storybook 8). Replaces the broken `backgrounds` approach that only painted the canvas colour without applying the `.dark` class to `<html>`.
- **`.storybook/preview.ts`** — replaced `parameters.backgrounds` with `withThemeByClassName` decorator from `@storybook/addon-themes`. Storybook toolbar now toggles real dark mode (`html.dark`) so all CSS variable overrides in `.dark { }` take effect. Dark mode visual regression is now verifiable in Storybook.

### Added (Automated Token Tests)

- **`src/design-system/contrast.test.ts`** — WCAG AA contrast ratio test suite (no DOM needed). Implements IEC 61966-2-1 relative luminance + `(L1+0.05)/(L2+0.05)` ratio. 12 assertions covering every light-mode semantic token pair. Two `it.skip` entries document open design decisions (destructive at 3.76:1 passes large-text AA only; muted-foreground on muted surface at 4.04:1 is 0.46 short of AA).
- **`src/design-system/tokens.sync.test.ts`** — CSS ↔ tokens.ts drift detection test. Parses `izivar-globals.css` at test time using `readFileSync`. Extracts vars from `:root` and `@theme inline` blocks separately (Tailwind v4 radius vars live in `@theme`, not `:root`). Extracts typography class names from `@layer components`. 4 assertions ensure every CSS variable is in `cssVar` (or explicitly excluded) and vice versa, and the same for typography. Exclusion list covers sidebar tokens and `--radius` (Tailwind utility tokens, not needed in JS).

### Added (Design Token Export)

- **`scripts/export-tokens.ts`** — reads `izivar-globals.css` at runtime and generates three W3C Design Token Community Group (DTCG) format JSON files:
  - `dist/tokens/tokens.light.json` — 36 light mode color tokens + 6 shape (radius) tokens
  - `dist/tokens/tokens.dark.json` — 36 dark mode oklch color tokens
  - `dist/tokens/tokens.typography.json` — 13 typography composite tokens (font-size, weight, line-height, letter-spacing)
- **`package.json`** — added `"tokens:export"` script: `node --experimental-strip-types scripts/export-tokens.ts`. Requires Node ≥ 22 (available in this repo). Run: `pnpm --filter @izivar/ux tokens:export`.
- **Import into Figma:** load each JSON file into **Tokens Studio for Figma** (free plugin) as a separate token set (`light`, `dark`, `typography`). Apply → Figma Variables are created automatically with light/dark as two modes.

### Fixed (tokens.ts)

- **`cssVar.popoverBorder`** — added `"--popover-border"` entry. Token was defined in `:root` but missing from `cssVar`; the sync test caught the drift.
- **`cssVar.radius`** — kept as-is; `--radius-sm/md/lg/xl` entries now validated against `@theme inline` block (not `:root`) in the sync test, fixing the false-positive orphan failure.
- **`typography.labelXs`** — added `"label-xs"` entry. Class was defined in `@layer components` but missing from `typography` map; the sync test caught the drift.

### Fixed (Type Errors)

- **`src/test/__mocks__/next-navigation.ts`** — `useRouter` was typed with an inferred return type that referenced an internal Vitest path, causing TS2742 (`implicitly has type 'any'`) during `tsc --noEmit`. Fixed with an explicit inline return type annotation.

### Fixed (Icon System — consistency audit 2026-06-05)

- **`Icon.tsx`** — `iconMap["more"]` pointed to `MenuIcon` (open-book glyph) instead of `MoreHorizontalIcon`. `<Icon name="more" />` now correctly renders three horizontal dots. `MoreHorizontalIcon` import added; unused second `MenuIcon` reference removed.
- **`NoImageIcon.tsx`** — only icon in the 75-component library missing `aria-hidden="true"` on its `<svg>` root. Attribute added; all 75 icons now carry `aria-hidden`.
- **`WarningTriangleIcon.tsx`** — default `size` prop was `64` while every other icon defaults to `24`. Normalized to `24`; callers that need a large empty-state size can still pass `size={64}` explicitly.
- **`AdminUsersIcon.tsx`** — default `size` was `32`. Normalized to `24` to match the library standard.
- **`ShoppingCartIcon.tsx`** — default `size` was `32`. Normalized to `24` to match the library standard.

### Added (Unit Tests — icon audit)

- **`src/shared/components/ui/Icon.test.tsx`** — added `"more"` to the renderable-icon smoke-test list; added a new assertion verifying `"more"` renders `MoreHorizontalIcon` (three `<circle>` elements, no `<line>`) and not the open-book `MenuIcon`. Guards against accidental re-regression of the icon-map bug.
- **`src/shared/icons/Icons.test.tsx`** (new, 17 tests) — individual icon tests for all four changed components: `NoImageIcon` (`aria-hidden`, default size 24, custom size, className), `WarningTriangleIcon` (default size 24 not 64, explicit large size still works, `aria-hidden`), `AdminUsersIcon` (default size 24 not 32, custom size, `aria-hidden`), `ShoppingCartIcon` (default size 24 not 32, custom size, `aria-hidden`).

### Fixed (WCAG 2.1 Contrast Violations)

- **`--primary-foreground`** changed from `#fff` to `#1e3350` (navy). Contrast on `--primary` (#FF6F61): **4.68:1** — passes WCAG AA normal text. Previously `#fff` gave 2.73:1 (fail).
- **`--secondary-foreground`** changed from `#fff` to `#1e3350`. Contrast on `--secondary` (#FFBE98): **7.95:1** — passes WCAG AA. Previously 1.61:1 (critical fail).
- **`--success-foreground`** changed from `#fff` to `#1e3350`. Contrast on `--success` (#22C55E): **5.60:1** — passes WCAG AA. Previously 2.28:1 (fail).
- **`--info-foreground`** changed from `#fff` to `#1e3350`. Contrast on `--info` (#0EA5E9): **4.61:1** — passes WCAG AA. Previously 2.77:1 (fail).
- **`button.tsx`** — removed all hardcoded `!text-white` overrides from `default`, `destructive`, `secondary`, and `outline` variants. All variants now use their semantic `text-*-foreground` tokens, allowing the CSS token changes above to take effect and enabling future token-only colour updates without touching component code.
- **`badge.tsx`** — `default`, `success`, and `secondary` variants changed from `text-primary`/`text-success`/`text-secondary` (semantic colours as text on tinted `bg-X/10` backgrounds — contrast ≈ 1.6–2.3:1) to `text-primary-foreground`/`text-success-foreground`/`text-secondary-foreground` (navy #1e3350 — contrast 12.77:1 on near-white). Semantic identity is still conveyed by the tinted background.
- **`StatusBadge.tsx`** — updated all status entries from `text-X` (the semantic colour as text on tinted bg, failing contrast) to `text-X-foreground` or `text-foreground`. Destructive entries (REJECTED, SUSPENDED, FAILED) changed to `text-foreground` specifically because `--destructive-foreground` is `#fff` which would be white-on-near-white on `bg-destructive/15`/`/10` tinted backgrounds.

### Added (WCAG Contrast Test)

- **`src/design-system/tokens.contrast.test.ts`** — programmatic WCAG 2.1 contrast ratio test. Implements the full IEC 61966-2-1 / WCAG relative luminance algorithm (linear channel expansion, `0.2126R + 0.7152G + 0.0722B`, `(L1 + 0.05)/(L2 + 0.05)` ratio). Tests every light-mode semantic token pair. Two `it.skip` entries document open issues that require a design decision before they can be resolved:
  - **Destructive open issue**: `#EF4444` achieves 3.76:1 with `#fff` and 3.39:1 with `#1e3350` — neither reaches 4.5:1. Fix requires darkening `--destructive` to `#C0392B` or equivalent. Passes AA large text (3.76 ≥ 3.0) for now.
  - **Muted open issue**: `#F5EBDD` / `#64748b` achieves 4.04:1 — 0.46 short of AA. Muted-foreground on the plain `background` (`#fff`) passes at 4.76:1. Fix requires darkening `--muted-foreground` to ≈ `#536070`.

### Added (Testing Infrastructure)

- **Vitest component test setup** — added `vitest.config.ts` configuring `jsdom` environment and `@vitejs/plugin-react`. Test runner now supports full React component rendering, user-event interactions, and accessibility-role queries. Run with `pnpm test`.
- **`@testing-library/react`**, **`@testing-library/user-event`**, **`@testing-library/jest-dom`**, **`jsdom`** added as devDependencies.
- **`src/test/setup.ts`** — global test setup file; imports `@testing-library/jest-dom` to extend Vitest `expect` with DOM matchers (`toBeInTheDocument`, `toHaveClass`, `toBeDisabled`, etc.).

### Added (Unit Tests — 150 tests across 19 files)

**UI Primitives**
- **`button.test.tsx`** — variant rendering (all 6 variants), size variants (default/sm/lg/icon), click handler, disabled state, `asChild` rendering as anchor, `type` attribute, custom `className` merge.
- **`badge.test.tsx`** — all variant class assertions (default/success/muted/warning/secondary), size sm/md, custom attributes pass-through.
- **`input.test.tsx`** — renders textbox, placeholder, typed input, `onChange` callback, disabled, `type` attribute (email/password), `maxLength`, custom `className`.
- **`alert.test.tsx`** — `role="alert"` presence, default and destructive variant classes, `AlertDescription` rendering.
- **`checkbox.test.tsx`** — unchecked default, `defaultChecked`, `onCheckedChange` callback, disabled state, `data-slot` attribute.
- **`switch.test.tsx`** — unchecked/checked `data-state`, toggle callback, disabled state, `data-slot` attribute.
- **`empty-state.test.tsx`** — message rendering, left-align default (no `text-center`), `align="center"` adds `text-center`, custom `className`.
- **`external-link.test.tsx`** — always `target="_blank"`, always `rel="noopener noreferrer"`, href, children, additional attributes pass-through.
- **`heading.test.tsx`** — default renders `h2`, `as` prop covers h1–h6, custom `className`, additional attributes.
- **`text.test.tsx`** — renders `<p>` tag, children, custom `className`, additional attributes.
- **`stepper.test.tsx`** — `nav[aria-label="Progress"]`, all step labels rendered, descriptions rendered, `aria-current="step"` on current step, correct listitem count, custom `className`.

**Data-Display**
- **`StatusBadge.test.tsx`** — `role="status"`, all 15 known status labels (ACTIVE → PRO), unknown status falls back to raw value, lowercase input normalised to uppercase, decorative dot present, custom `className`.
- **`StatCard.test.tsx`** — label, numeric value, string value, icon rendered when provided / absent when not, subtext conditional rendering, default variant.
- **`PageHeader.test.tsx`** — title as `h1`, description conditional, badge slot, actions slot, custom `className`.
- **`ConfirmDialog.test.tsx`** — renders when open, hidden when closed, default/custom button labels, `onConfirm`/`onCancel` callbacks, loading state disables both buttons and shows "Processing…", `aria-busy="true"` on loading confirm, `destructive` class on `variant="danger"`.

**Hooks**
- **`useDebounce.test.ts`** — returns initial value immediately, does not update before delay, updates after delay, resets timer on rapid changes, default 300ms delay, generic type support.
- **`useMediaQuery.test.ts`** — returns `false` before mount (SSR-safe), `true` when query matches, `false` when not, updates on `change` event, removes listener on unmount.
- **`useClickOutside.test.ts`** — fires on `mousedown` outside, suppresses on click inside, fires on `touchstart` outside, removes both listeners on unmount, safe when `ref.current` is null.

### Added

- **`SplitButton`** (`src/components/ui/split-button.tsx`) — primary action button with a dropdown for secondary actions. Built on `Button` + `DropdownMenu`. Props: `label`, `actions` (`{label, onClick, disabled?, destructive?}[]`), `loading`, `variant`, `size`. Exports: `SplitButton`, `SplitButtonProps`, `SplitButtonAction`.
- **`List`** / **`ListItem`** / **`ListHeader`** (`src/components/ui/list.tsx`) — structured list display. `List` supports `ordered` and `divided` props. `ListItem` supports `leading`, `trailing`, `description`, `interactive` slots. `ListHeader` renders a section label. Exports: `List`, `ListItem`, `ListHeader`, `ListProps`, `ListItemProps`, `ListHeaderProps`.
- **`useDebounce`** (`src/hooks/useDebounce.ts`) — delays updating a value until input stops changing. Default delay 300ms. Generic `<T>`.
- **`useMediaQuery`** (`src/hooks/useMediaQuery.ts`) — tracks CSS media query matches. SSR-safe (returns `false` on server).
- **`useClickOutside`** (`src/hooks/useClickOutside.ts`) — fires a handler on click/touch outside a referenced element. Attaches both `mousedown` and `touchstart`.
- **Storybook** — set up with `@storybook/react-vite` + `@tailwindcss/vite`. Stories added for `Button`, `Badge`, `Tooltip`, `Tabs`, `StatusBadge`. Run with `pnpm storybook` (port 6006).
- **`Breadcrumb`** (`src/components/ui/breadcrumb.tsx`) — navigation breadcrumb trail. Exports: `Breadcrumb`, `BreadcrumbList`, `BreadcrumbItem`, `BreadcrumbLink`, `BreadcrumbPage`, `BreadcrumbSeparator`, `BreadcrumbEllipsis`. Uses `ChevronRightIcon` / `MoreHorizontalIcon` from the izivar icon set (no lucide dependency).
- **`Slider`** (`src/components/ui/slider.tsx`) — range input built on Radix Slider. Single value and range mode. Styled with `bg-primary` track fill.
- **`Toggle`** (`src/components/ui/toggle.tsx`) — single toggle button with `default` and `outline` variants, three sizes. Exports: `Toggle`, `toggleVariants`.
- **`ToggleGroup`** (`src/components/ui/toggle-group.tsx`) — group of toggle buttons, single or multiple selection. Exports: `ToggleGroup`, `ToggleGroupItem`.
- **`Stepper`** (`src/components/ui/stepper.tsx`) — vertical step progress indicator for multi-step flows (onboarding, booking). Props: `steps` (`{id, label, description?}[]`), `currentStep` (0-based index). Completed steps show `CheckIcon`; current step shows filled dot; upcoming steps show step number. Exports: `Stepper`, `StepperProps`, `Step`, `StepStatus`.
- **`Progress`** (`src/components/ui/progress.tsx`) — horizontal progress bar built on Radix Progress. Use for booking flow progress, file uploads. Props: `value` (0–100).
- **`Tooltip`** (`src/components/ui/tooltip.tsx`) — Radix-based tooltip for contextual hints. Exports: `Tooltip`, `TooltipTrigger`, `TooltipContent`, `TooltipProvider`. `TooltipProvider` is auto-wrapped inside `Tooltip` so single-use is zero-boilerplate. Arrow included by default.
- **`Tabs`** (`src/components/ui/tabs.tsx`) — Radix-based tab navigation. Exports: `Tabs`, `TabsList`, `TabsTrigger`, `TabsContent`. Active tab uses `bg-background` + shadow; inactive uses `text-muted-foreground` with hover.
- **`Command`** (`src/components/ui/command.tsx`) — `cmdk`-based command palette primitive. Exports: `Command`, `CommandInput`, `CommandList`, `CommandEmpty`, `CommandGroup`, `CommandItem`, `CommandSeparator`. Foundation for `Combobox` and future command palettes.
- **`Combobox`** (`src/components/ui/combobox.tsx`) — searchable select built on `Popover` + `Command`. Props: `options` (`{value, label}[]`), `value`, `onValueChange`, `placeholder`, `searchPlaceholder`, `emptyText`, `disabled`, `className`. Width matches trigger via `--radix-popover-trigger-width`. Exported as `Combobox`, `ComboboxOption`, `ComboboxProps`.

- **`Article`** (`src/components/ui/article.tsx`) — semantic `<article>` element for self-contained content units (blog posts, journal cards). Supports `ref` forwarding. Styling applied via `className`. Exported as `Article`, `ArticleProps`.
- **`Blockquote`** (`src/components/ui/blockquote.tsx`) — semantic `<blockquote>` element. Typography applied via design-system CSS utility classes in `className`. Exported as `Blockquote`, `BlockquoteProps`.
- **`Heading`** (`src/components/ui/heading.tsx`) — semantic heading element (`h1`–`h6`). Enforces the correct tag; typography applied via design-system CSS utility classes (`headline-large`, `headline-medium`, `headline-small`, `title-large`, `title-medium`, `title-small`) in `className`. Props: `as` (`h1`–`h6`, default `h2`), `className`. Exported as `Heading`, `HeadingProps`.
- **`Text`** (`src/components/ui/text.tsx`) — semantic `<p>` element. Typography applied via design-system CSS utility classes (`paragraph-large`, `paragraph-medium`, `paragraph-small`, `label-large`, `label-medium`, `label-small`, `label-xs`) in `className`. Props: `className`. Exported as `Text`, `TextProps`.
- **`Badge`** (`src/components/ui/badge.tsx`) — inline label component for status, tags, and verification markers. Variants: `default`, `success`, `muted`, `outline`, `contrast`, `warning`, `secondary`. Sizes: `sm` (default), `md`. Exported as `Badge`, `BadgeProps`, `badgeVariants`.
- **`SectionHeader`** (`src/shared/components/ui/SectionHeader.tsx`) — eyebrow + heading pattern with optional trailing action and decorative divider. Props: `eyebrow`, `heading`, `align` (`left` | `center`), `showDivider`, `action`, `className`. Exported as `SectionHeader`, `SectionHeaderProps`.
- **`CardImageSkeleton`** (`src/shared/components/ui/Skeleton.tsx`) — loading placeholder for image cards (hotel, event, stay). Renders an aspect-ratio image block above configurable text lines. Props: `aspectRatio` (default `aspect-[3/2]`), `lines` (default 2), `className`. Exported as `CardImageSkeleton`, `CardImageSkeletonProps`.
- **`ExternalLink`** (`src/components/ui/external-link.tsx`) — safe external anchor component. Always applies `target="_blank"` and `rel="noopener noreferrer"`. Use instead of raw `<a>` for any link pointing outside the app. Exported as `ExternalLink`, `ExternalLinkProps`.
- **`LandingHeader`** (`src/platform/LandingHeader.tsx`) — fixed top nav for consumer landing pages. Handles brand link, desktop nav links, primary/secondary CTAs (internal `Link` or external `<a>` via `external` flag), and a controlled mobile menu slot (`mobileMenuContent`). No hardcoded routes or labels — all config passed as props. Exported as `LandingHeader`, `LandingHeaderProps`, `LandingHeaderNavLink`, `LandingHeaderCta`.

---

## [0.2.0] - 2026-05-30

### Changed

- **`src/styles/izivar-globals.css` `@theme inline`** — updated `--font-sans` fallback chain from `'Source Sans Pro'` (v2 name) to `'Source Sans 3', 'Source Sans Pro'` to match the v3 typeface name loaded by consuming apps via `next/font/google`. No visual change — `next/font` overrides this variable at runtime.
- **`src/design-system/tokens.ts`** — completed `cssVar` to cover all 29 CSS variables defined in `:root` / `.dark` (previously 12). Added `typography` constant mapping all 12 typography class names to typed strings. Added `CssVar` and `TypographyClass` union types. Fixed stale file-path comment.
- **`src/design-system/index.ts`** — exports `typography`, `CssVar`, `TypographyClass` from the public surface. Removed stale comment.
- **`ConfirmDialog`**, **`RejectDialog`**, **`SuspendDialog`** — migrated from custom fixed-position overlay to Radix Dialog primitives. Gains native focus trap, ESC key close, and focus restore on dismiss. Public props interface unchanged — no consumer changes required.
- **`izivar-globals.css` typography scale** — rewrote all 12 typography utility classes (`.headline-*`, `.title-*`, `.paragraph-*`, `.label-*`) with fluid `clamp()` sizing, correct per-tier weights (700 / 600 / 400), letter-spacing, and semantic colours. Eliminates stepped `@media` blocks. Same class names — no consumer changes required.

### Fixed

- **`SavedBanner`** — replaced hardcoded Tailwind `green-50`/`green-700` colour classes with design-token classes `bg-success/10 text-success` so the component respects the active theme.

---

## [0.1.0] - 2026-05-13

### Added

- Initial release: 23 UI primitives, 8 data-display components, 77 SVG icons, platform chrome (Header, Footer), design token system, and fluid typography scale.
- Changelog established. Maintain **`[Unreleased]`** during development and roll entries into a dated section when cutting **`vX.Y.Z`**.
