import type { Meta, StoryObj } from "@storybook/react";

const meta: Meta = { title: "Foundation/Typography" };
export default meta;
type Story = StoryObj;

// ── Scale row ────────────────────────────────────────────────────────────────

function Row({
  cls,
  label,
  size,
  weight,
  sample,
}: {
  cls: string;
  label: string;
  size: string;
  weight: string;
  sample: string;
}) {
  return (
    <div className="grid grid-cols-[180px_100px_100px_1fr] items-baseline gap-4 border-b border-border py-4 last:border-0">
      <div className="flex flex-col gap-0.5">
        <span className="text-xs font-mono text-primary">.{cls}</span>
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <span className="text-xs text-muted-foreground tabular-nums">{size}</span>
      <span className="text-xs text-muted-foreground">{weight}</span>
      <p className={cls}>{sample}</p>
    </div>
  );
}

// ── Full scale ───────────────────────────────────────────────────────────────

export const Scale: Story = {
  render: () => (
    <div className="w-full max-w-4xl space-y-10 p-6">

      {/* Header */}
      <div className="space-y-1">
        <h2 className="headline-small">Typography Scale</h2>
        <p className="paragraph-medium text-muted-foreground">
          Source Sans 3 · Mobile-first fluid sizing · Token-driven colors
        </p>
      </div>

      {/* Column headers */}
      <div className="grid grid-cols-[180px_100px_100px_1fr] gap-4 border-b border-border pb-2">
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Class</span>
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Size</span>
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Weight</span>
        <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Sample</span>
      </div>

      {/* Headline */}
      <section className="space-y-0">
        <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Headline</p>
        <Row cls="headline-large"  label="Page title"        size="24→36px" weight="700" sample="Welcome to Izivar" />
        <Row cls="headline-medium" label="Section title"     size="20→30px" weight="700" sample="Browse Properties" />
        <Row cls="headline-small"  label="Card / sub-title"  size="18→24px" weight="700" sample="Sunrise Retreat, Coorg" />
      </section>

      {/* Title */}
      <section className="space-y-0">
        <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Title</p>
        <Row cls="title-large"  label="Modal / drawer"     size="18→24px" weight="600" sample="Booking Summary" />
        <Row cls="title-medium" label="Panel heading"      size="16→20px" weight="600" sample="Guest Information" />
        <Row cls="title-small"  label="Widget / stat"      size="14→16px" weight="600" sample="Total Revenue" />
      </section>

      {/* Paragraph */}
      <section className="space-y-0">
        <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Paragraph</p>
        <Row cls="paragraph-large"  label="Lead / intro"   size="16px (fixed)" weight="400" sample="Find and book the perfect mountain retreat, beachside villa, or heritage haveli." />
        <Row cls="paragraph-medium" label="Body copy"      size="14px (fixed)" weight="400" sample="Your booking includes complimentary breakfast, free cancellation up to 24 hours before check-in, and access to all amenities." />
        <Row cls="paragraph-small"  label="Caption / meta" size="12px (fixed)" weight="400" sample="Check-in after 2:00 PM · Check-out before 11:00 AM · Non-refundable after 48 hrs" />
      </section>

      {/* Label */}
      <section className="space-y-0">
        <p className="mb-2 text-xs font-bold uppercase tracking-widest text-muted-foreground">Label</p>
        <Row cls="label-large"  label="Nav / button"     size="16px (fixed)" weight="600" sample="Book Now" />
        <Row cls="label-medium" label="Form label / tag" size="14px (fixed)" weight="600" sample="Mobile Number" />
        <Row cls="label-small"  label="Helper / caption" size="12px (fixed)" weight="600" sample="We'll send an OTP to verify your number" />
        <Row cls="label-xs"     label="Eyebrow / micro"  size="10px (fixed)" weight="700" sample="FEATURED PROPERTY" />
      </section>

    </div>
  ),
};

// ── Usage in context ─────────────────────────────────────────────────────────

export const InContext: Story = {
  name: "In Context — Hotel Card",
  render: () => (
    <div className="w-80 rounded-xl border border-border bg-card p-5 shadow-card space-y-3">
      <div className="space-y-0.5">
        <p className="label-xs text-primary">FEATURED</p>
        <h3 className="title-large">Sunrise Retreat</h3>
        <p className="paragraph-small text-muted-foreground">Coorg, Karnataka</p>
      </div>
      <p className="paragraph-medium">
        A serene hillside escape with panoramic views, organic meals, and guided forest walks.
      </p>
      <div className="flex items-center justify-between pt-1 border-t border-border">
        <div>
          <span className="headline-small text-primary">₹4,800</span>
          <span className="label-small"> / night</span>
        </div>
        <span className="label-medium text-success">4.9 ★</span>
      </div>
    </div>
  ),
};

export const ColorTokens: Story = {
  name: "Color Tokens on Text",
  render: () => (
    <div className="space-y-3 p-6">
      <p className="paragraph-medium text-foreground">text-foreground — default body text</p>
      <p className="paragraph-medium text-muted-foreground">text-muted-foreground — secondary / helper</p>
      <p className="paragraph-medium text-primary">text-primary — brand / interactive</p>
      <p className="paragraph-medium text-destructive">text-destructive — error / danger</p>
      <p className="paragraph-medium text-success">text-success — positive / confirmed</p>
      <p className="paragraph-medium text-warning">text-warning — caution / pending</p>
    </div>
  ),
};
