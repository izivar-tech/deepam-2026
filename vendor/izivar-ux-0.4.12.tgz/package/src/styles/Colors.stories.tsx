import type { Meta, StoryObj } from "@storybook/react";

const meta: Meta = { title: "Foundation/Colors" };
export default meta;
type Story = StoryObj;

// ── Swatch — solid color block, no foreground text ───────────────────────────

function Swatch({ bg, label, variable }: { bg: string; label: string; variable: string }) {
  return (
    <div className="flex flex-col overflow-hidden rounded-md border border-border">
      <div className="h-16 w-full" style={{ background: `var(${bg})` }} />
      <div className="space-y-0.5 bg-card p-2">
        <p className="text-xs font-semibold text-foreground">{label}</p>
        <p className="font-mono text-[10px] text-muted-foreground">{variable}</p>
      </div>
    </div>
  );
}

// ── PairSwatch — bg + fg contrast demo ──────────────────────────────────────

function PairSwatch({
  bg,
  fg,
  label,
  variable,
}: {
  bg: string;
  fg: string;
  label: string;
  variable: string;
}) {
  return (
    <div className="flex flex-col overflow-hidden rounded-md border border-border">
      <div
        className="flex h-16 w-full items-center justify-center"
        style={{ background: `var(${bg})` }}
      >
        <span className="text-sm font-semibold" style={{ color: `var(${fg})` }}>
          Aa
        </span>
      </div>
      <div className="space-y-0.5 bg-card p-2">
        <p className="text-xs font-semibold text-foreground">{label}</p>
        <p className="font-mono text-[10px] text-muted-foreground">{variable}</p>
      </div>
    </div>
  );
}

// ── Section ──────────────────────────────────────────────────────────────────

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">{title}</p>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(140px,1fr))] gap-3">
        {children}
      </div>
    </div>
  );
}

// ── Stories ──────────────────────────────────────────────────────────────────

export const Palette: Story = {
  render: () => (
    <div className="w-full max-w-4xl space-y-10 p-6">

      <div className="space-y-1">
        <h2 className="headline-small">Color Tokens</h2>
        <p className="paragraph-medium text-muted-foreground">
          All semantic tokens from{" "}
          <span className="font-mono text-sm">izivar-globals.css</span>. Use via Tailwind utilities — never hardcode hex.
        </p>
      </div>

      <Section title="Brand">
        <PairSwatch bg="--primary"   fg="--primary-foreground"   label="Primary"   variable="--primary" />
        <PairSwatch bg="--secondary" fg="--secondary-foreground" label="Secondary" variable="--secondary" />
        <Swatch     bg="--ring"                                  label="Ring / Focus" variable="--ring" />
      </Section>

      <Section title="Surface">
        <PairSwatch bg="--background" fg="--foreground"           label="Background" variable="--background" />
        <PairSwatch bg="--card"       fg="--card-foreground"      label="Card"       variable="--card" />
        <PairSwatch bg="--popover"    fg="--popover-foreground"   label="Popover"    variable="--popover" />
        <PairSwatch bg="--muted"      fg="--muted-foreground"     label="Muted"      variable="--muted" />
        <PairSwatch bg="--accent"     fg="--accent-foreground"    label="Accent"     variable="--accent" />
      </Section>

      <Section title="Semantic">
        <PairSwatch bg="--destructive" fg="--destructive-foreground" label="Destructive" variable="--destructive" />
        <PairSwatch bg="--success"     fg="--success-foreground"     label="Success"     variable="--success" />
        <PairSwatch bg="--warning"     fg="--warning-foreground"     label="Warning"     variable="--warning" />
        <PairSwatch bg="--info"        fg="--info-foreground"        label="Info"        variable="--info" />
      </Section>

      <Section title="Border & Input">
        <Swatch bg="--border" label="Border" variable="--border" />
        <Swatch bg="--input"  label="Input"  variable="--input" />
      </Section>

      <Section title="Sidebar">
        <PairSwatch bg="--sidebar"         fg="--sidebar-foreground"         label="Sidebar"         variable="--sidebar" />
        <PairSwatch bg="--sidebar-primary" fg="--sidebar-primary-foreground" label="Sidebar Primary" variable="--sidebar-primary" />
        <PairSwatch bg="--sidebar-accent"  fg="--sidebar-accent-foreground"  label="Sidebar Accent"  variable="--sidebar-accent" />
        <Swatch     bg="--sidebar-border"                                    label="Sidebar Border"  variable="--sidebar-border" />
      </Section>

    </div>
  ),
};

export const TextColors: Story = {
  name: "Text Colors",
  render: () => (
    <div className="w-full max-w-2xl space-y-10 p-6">
      <div className="space-y-1">
        <h2 className="headline-small">Text Color Tokens</h2>
        <p className="paragraph-medium text-muted-foreground">
          Apply via <span className="font-mono text-sm">text-*</span> utilities.
        </p>
      </div>

      <div className="space-y-0">
        {[
          { token: "--foreground",         cls: "text-foreground",         desc: "Default body text" },
          { token: "--muted-foreground",   cls: "text-muted-foreground",   desc: "Secondary / helper / placeholder" },
          { token: "--primary",            cls: "text-primary",            desc: "Brand / interactive / links" },
          { token: "--secondary",          cls: "text-secondary",          desc: "Peach tint — decorative" },
          { token: "--destructive",        cls: "text-destructive",        desc: "Errors / danger states" },
          { token: "--success",            cls: "text-success",            desc: "Confirmed / positive" },
          { token: "--warning",            cls: "text-warning",            desc: "Caution / pending review" },
          { token: "--info",               cls: "text-info",               desc: "Informational / neutral alert" },
          { token: "--card-foreground",    cls: "text-card-foreground",    desc: "Text on card surfaces" },
          { token: "--popover-foreground", cls: "text-popover-foreground", desc: "Text in popovers / dropdowns" },
        ].map(({ token, cls, desc }) => (
          <div key={token} className="grid grid-cols-[220px_1fr] items-center gap-4 border-b border-border py-3 last:border-0">
            <div className="space-y-0.5">
              <p className="font-mono text-xs text-primary">{cls}</p>
              <p className="text-xs text-muted-foreground">{desc}</p>
            </div>
            <p
              className="paragraph-medium"
              style={{ color: `var(${token})` }}
            >
              The quick brown fox jumps over the lazy dog
            </p>
          </div>
        ))}
      </div>
    </div>
  ),
};

export const SemanticUsage: Story = {
  name: "Semantic — When to Use",
  render: () => (
    <div className="w-full max-w-2xl space-y-4 p-6">
      <h2 className="headline-small">Semantic Color Usage</h2>

      {[
        {
          bg: "--primary",
          border: "--primary",
          text: "--primary",
          title: "Primary — Brand & Actions",
          usage: "CTA buttons, active nav items, links, focus rings, selected states.",
          example: "Book Now · Approve · Submit",
        },
        {
          bg: "--success",
          border: "--success",
          text: "--success",
          title: "Success — Confirmed States",
          usage: "Booking confirmed, payment received, hotel approved, upload complete.",
          example: "Booking Confirmed · Payment Received",
        },
        {
          bg: "--warning",
          border: "--warning",
          text: "--warning",
          title: "Warning — Needs Attention",
          usage: "Pending review, expiring soon, incomplete profile, low availability.",
          example: "Pending Review · Expires in 2 days",
        },
        {
          bg: "--destructive",
          border: "--destructive",
          text: "--destructive",
          title: "Destructive — Errors & Danger",
          usage: "Form validation errors, delete actions, suspended accounts, failed payments.",
          example: "Delete Property · Payment Failed",
        },
        {
          bg: "--info",
          border: "--info",
          text: "--info",
          title: "Info — Neutral Guidance",
          usage: "Tips, onboarding hints, help text, system notices.",
          example: "Add at least 5 photos to attract more bookings",
        },
        {
          bg: "--muted",
          border: "--border",
          text: "--muted-foreground",
          title: "Muted — Secondary Surface",
          usage: "Disabled states, empty state backgrounds, table header rows, skeleton loaders.",
          example: "No bookings found · Loading…",
        },
      ].map(({ bg, border, text, title, usage, example }) => (
        <div
          key={title}
          className="rounded-md border p-4 space-y-1"
          style={{
            background: `color-mix(in srgb, var(${bg}) 10%, transparent)`,
            borderColor: `color-mix(in srgb, var(${border}) 30%, transparent)`,
          }}
        >
          <p className="label-medium" style={{ color: `var(${text})` }}>{title}</p>
          <p className="paragraph-small text-muted-foreground">{usage}</p>
          <p className="label-small" style={{ color: `var(${text})` }}>{example}</p>
        </div>
      ))}
    </div>
  ),
};
